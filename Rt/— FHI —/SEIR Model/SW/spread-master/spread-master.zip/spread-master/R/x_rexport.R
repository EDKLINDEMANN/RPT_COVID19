#' @import data.table
#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`

`%dopar%` <- foreach::`%dopar%`
