## Resubmission

## Changes made

- Fixed DOI in inst/doc/commuter_model.html

## Test environments
* local Debian 9.5 install, R 3.6.0
* ubuntu 14.04 (on travis-ci), R 3.6.1
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 1 note

* checking CRAN incoming feasibility ... NOTE
Maintainer: 'Richard White <w@rwhite.no>'

New submission

## Downstream dependencies

none
