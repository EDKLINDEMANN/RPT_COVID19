## Notes to CRAN

This fixes tests failing on R 3.6.0 due to the RNG bugfix.

## Test environments

* ubuntu 16.04, R 3.5.3
* MacOS 10.14.2, R 3.5.3
* ubuntu 14.04, (on travis-ci), 
* ubuntu 14.04 (on travis-ci), R devel [2019-03-13 r76228]
* win-builder (devel [2019-03-11 r76226] and release)

## R CMD check results

0 errors | 0 warnings | 0 note

## CRAN check results

all OK

